using UnityEngine.UIElements;

namespace Unity.Cloud.Collaborate.EditorGameService.SettingsProviderVisuals
{
    interface IVisuals
    {
        VisualElement GetVisuals();
    }
}
