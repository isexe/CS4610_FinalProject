﻿namespace Unity.PlasticSCM.Editor.UI
{
    internal enum ResponseType
    {
        None,
        Ok,
        Cancel,
        Apply
    }
}
